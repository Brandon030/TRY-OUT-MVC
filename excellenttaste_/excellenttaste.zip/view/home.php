<?php include 'header.php'; ?>
<body>
	<div class="row">
		<div class="col-lg6" style="text-align: center; width: 50%;">awo welkom bij excellent taste, wij zijn gek en moeten dit examen wel halen anders gaan we dood en dat moeten we natuurlijk niet hebben dus bij deze geniet van deze website en uhh geef mij een voldoende.</div>
		<div class="col-lg6"><img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/800x600_Wallpaper_Blue_Sky.png" /></div>
	</div>
</body>
<?php include 'footer.php'; ?>
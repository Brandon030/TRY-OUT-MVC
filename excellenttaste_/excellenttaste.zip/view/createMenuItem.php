<?php
	header("Location: ./?op=readDrinken");
?>
<h1 style="text-align: center;">Bestelling is verwijderd</h1>

<div style="text-align:center;"><a href="?op=readReserveringen"><button class="btn btn-dark" style="align-self: center;">klik hier om terug te gaan</button></a></div>

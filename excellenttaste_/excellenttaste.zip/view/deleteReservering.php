<?php include 'header.php'; ?>

<h1 style="text-align: center;">de gekozen reservering is verwijderd</h1>

<div style="text-align:center;"><a href="?op=readReservering"><button class="btn btn-dark" style="align-self: center;">klik hier om terug te gaan</button></a></div>

<?php include 'footer.php'; ?>